// src/components/index.js
export { default as UserProfile } from "./UserProfile";
export { default as SideNavBar } from "./SideNavBar";
