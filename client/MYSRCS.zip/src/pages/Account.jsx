import React, { useState } from "react";
import { Link } from "react-router-dom";
import { SideNavBar, UserProfile } from "../components";

const Account = () => {
  const [userData, setUserData] = useState({
    username: "kartracer_11",
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    phone: "+92 123 456 7890",
    profileImage: null
  });

  const [passwords, setPasswords] = useState({
    current: "",
    new: "",
    confirm: ""
  });

  // Handle profile image upload
  const [profileImagePreview, setProfileImagePreview] = useState(null);
  
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Create a preview URL
      const previewUrl = URL.createObjectURL(file);
      setProfileImagePreview(previewUrl);
      
      // Update user data (in a real app, you would send this to the server)
      setUserData({...userData, profileImage: file});
    }
  };

  // Handle form input changes
  const handleUserDataChange = (e) => {
    const { name, value } = e.target;
    setUserData({...userData, [name]: value});
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswords({...passwords, [name]: value});
  };

  // Handle form submissions
  const handleProfileSubmit = (e) => {
    e.preventDefault();
    // In a real app, you would send this data to the server
    alert("Profile updated successfully!");
  };

  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    if (passwords.new !== passwords.confirm) {
      alert("New passwords don't match!");
      return;
    }
    // In a real app, you would send this data to the server
    alert("Password updated successfully!");
    setPasswords({ current: "", new: "", confirm: "" });
  };

  return (
    <div
      style={{
        width: "100%",
        minHeight: "982px",
        position: "relative",
        background: "linear-gradient(90deg, black 26%, #1B1B1B 53%, #1F1F1F 74%, #242424 83%, #272727 93%)",
        overflow: "hidden",
        paddingBottom: "40px",
      }}
    >
      <SideNavBar />
      <UserProfile style={{ position: "absolute", top: 30, right: 40 }} />

      <div
        style={{
          position: "absolute",
          left: 363,
          top: 100,
          width: "calc(100% - 400px)",
          maxWidth: "1200px",
          zIndex: 5,
        }}
      >
        <h1
          style={{
            color: "#c9c0c0",
            fontSize: 26,
            fontFamily: "Readex Pro, sans-serif",
            fontWeight: 700,
            marginBottom: 30,
          }}
        >
          ACCOUNT SETTINGS
        </h1>

        <div style={{ display: "flex", gap: 30, flexWrap: "wrap" }}>
          {/* Profile Picture Card */}
          <div
            style={{
              background: "rgba(30, 30, 30, 0.7)",
              borderRadius: 15,
              border: "1px solid #3d3d3d",
              padding: "30px",
              width: "300px",
              marginBottom: "30px",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "25px",
              }}
            >
              <div
                style={{
                  width: 24,
                  height: 24,
                  marginRight: 10,
                  opacity: 0.8,
                }}
              >
                📷
              </div>
              <div
                style={{
                  color: "#f7f4f1",
                  fontFamily: "Readex Pro, sans-serif",
                  fontSize: 18,
                  fontWeight: 600,
                }}
              >
                PROFILE PICTURE
              </div>
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 20,
              }}
            >
              <div
                style={{
                  width: 160,
                  height: 160,
                  borderRadius: "50%",
                  backgroundColor: "#2a2a2a",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  overflow: "hidden",
                  border: "3px solid #3d3d3d",
                }}
              >
                {profileImagePreview ? (
                  <img
                    src={profileImagePreview}
                    alt="Profile Preview"
                    style={{ width: "100%", height: "100%", objectFit: "cover" }}
                  />
                ) : (
                  <span style={{ fontSize: 60, color: "#c0c0c0" }}>👤</span>
                )}
              </div>

              <label
                style={{
                  background: "linear-gradient(90deg, #300101 6%, #7b0303 50%, #960404 95%)",
                  border: "none",
                  borderRadius: 8,
                  padding: "10px 20px",
                  color: "#f7f4f1",
                  fontSize: 14,
                  fontWeight: 600,
                  cursor: "pointer",
                  textAlign: "center",
                  width: "80%",
                }}
              >
                Upload Photo
                <input
                  type="file"
                  accept="image/*"
                  style={{ display: "none" }}
                  onChange={handleImageChange}
                />
              </label>
            </div>
          </div>

          {/* Edit Profile Card */}
          <div
            style={{
              background: "rgba(30, 30, 30, 0.7)",
              borderRadius: 15,
              border: "1px solid #3d3d3d",
              padding: "30px",
              flex: 1,
              minWidth: "300px",
              marginBottom: "30px",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "25px",
              }}
            >
              <div
                style={{
                  width: 24,
                  height: 24,
                  marginRight: 10,
                  opacity: 0.8,
                }}
              >
                👤
              </div>
              <div
                style={{
                  color: "#f7f4f1",
                  fontFamily: "Readex Pro, sans-serif",
                  fontSize: 18,
                  fontWeight: 600,
                }}
              >
                EDIT PROFILE
              </div>
            </div>

            <form onSubmit={handleProfileSubmit}>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
                  gap: 20,
                }}
              >
                {/* First Name */}
                <div>
                  <label
                    style={{
                      display: "block",
                      color: "#f7f4f1",
                      fontFamily: "Readex Pro, sans-serif",
                      fontSize: 14,
                      marginBottom: 8,
                    }}
                  >
                    First Name
                  </label>
                  <input
                    type="text"
                    name="firstName"
                    value={userData.firstName}
                    onChange={handleUserDataChange}
                    style={{
                      width: "100%",
                      height: 45,
                      background: "rgba(240, 240, 240, 0.1)",
                      border: "none",
                      borderRadius: 8,
                      padding: "0 15px",
                      color: "#f7f4f1",
                      fontSize: 16,
                    }}
                    required
                  />
                </div>

                {/* Last Name */}
                <div>
                  <label
                    style={{
                      display: "block",
                      color: "#f7f4f1",
                      fontFamily: "Readex Pro, sans-serif",
                      fontSize: 14,
                      marginBottom: 8,
                    }}
                  >
                    Last Name
                  </label>
                  <input
                    type="text"
                    name="lastName"
                    value={userData.lastName}
                    onChange={handleUserDataChange}
                    style={{
                      width: "100%",
                      height: 45,
                      background: "rgba(240, 240, 240, 0.1)",
                      border: "none",
                      borderRadius: 8,
                      padding: "0 15px",
                      color: "#f7f4f1",
                      fontSize: 16,
                    }}
                    required
                  />
                </div>

                {/* Username */}
                <div>
                  <label
                    style={{
                      display: "block",
                      color: "#f7f4f1",
                      fontFamily: "Readex Pro, sans-serif",
                      fontSize: 14,
                      marginBottom: 8,
                    }}
                  >
                    Username
                  </label>
                  <input
                    type="text"
                    name="username"
                    value={userData.username}
                    onChange={handleUserDataChange}
                    style={{
                      width: "100%",
                      height: 45,
                      background: "rgba(240, 240, 240, 0.1)",
                      border: "none",
                      borderRadius: 8,
                      padding: "0 15px",
                      color: "#f7f4f1",
                      fontSize: 16,
                    }}
                    required
                  />
                </div>

                {/* Phone Number */}
                <div>
                  <label
                    style={{
                      display: "block",
                      color: "#f7f4f1",
                      fontFamily: "Readex Pro, sans-serif",
                      fontSize: 14,
                      marginBottom: 8,
                    }}
                  >
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={userData.phone}
                    onChange={handleUserDataChange}
                    style={{
                      width: "100%",
                      height: 45,
                      background: "rgba(240, 240, 240, 0.1)",
                      border: "none",
                      borderRadius: 8,
                      padding: "0 15px",
                      color: "#f7f4f1",
                      fontSize: 16,
                    }}
                  />
                </div>

                {/* Email */}
                <div>
                  <label
                    style={{
                      display: "block",
                      color: "#f7f4f1",
                      fontFamily: "Readex Pro, sans-serif",
                      fontSize: 14,
                      marginBottom: 8,
                    }}
                  >
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={userData.email}
                    onChange={handleUserDataChange}
                    style={{
                      width: "100%",
                      height: 45,
                      background: "rgba(240, 240, 240, 0.1)",
                      border: "none",
                      borderRadius: 8,
                      padding: "0 15px",
                      color: "#f7f4f1",
                      fontSize: 16,
                    }}
                    required
                  />
                </div>
              </div>

              <div style={{ marginTop: 30, display: "flex", justifyContent: "flex-end" }}>
                <button
                  type="submit"
                  style={{
                    background: "linear-gradient(90deg, #300101 6%, #7b0303 50%, #960404 95%)",
                    border: "none",
                    borderRadius: 8,
                    padding: "10px 30px",
                    color: "#f7f4f1",
                    fontSize: 16,
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>

          {/* Change Password Card */}
          <div
            style={{
              background: "rgba(30, 30, 30, 0.7)",
              borderRadius: 15,
              border: "1px solid #3d3d3d",
              padding: "30px",
              width: "100%",
              marginBottom: "30px",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "25px",
              }}
            >
              <div
                style={{
                  width: 24,
                  height: 24,
                  marginRight: 10,
                  opacity: 0.8,
                }}
              >
                🔒
              </div>
              <div
                style={{
                  color: "#f7f4f1",
                  fontFamily: "Readex Pro, sans-serif",
                  fontSize: 18,
                  fontWeight: 600,
                }}
              >
                CHANGE PASSWORD
              </div>
            </div>

            <form onSubmit={handlePasswordSubmit}>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
                  gap: 20,
                }}
              >
                {/* Current Password */}
                <div>
                  <label
                    style={{
                      display: "block",
                      color: "#f7f4f1",
                      fontFamily: "Readex Pro, sans-serif",
                      fontSize: 14,
                      marginBottom: 8,
                    }}
                  >
                    Current Password
                  </label>
                  <input
                    type="password"
                    name="current"
                    value={passwords.current}
                    onChange={handlePasswordChange}
                    style={{
                      width: "100%",
                      height: 45,
                      background: "rgba(240, 240, 240, 0.1)",
                      border: "none",
                      borderRadius: 8,
                      padding: "0 15px",
                      color: "#f7f4f1",
                      fontSize: 16,
                    }}
                    required
                  />
                </div>

                {/* New Password */}
                <div>
                  <label
                    style={{
                      display: "block",
                      color: "#f7f4f1",
                      fontFamily: "Readex Pro, sans-serif",
                      fontSize: 14,
                      marginBottom: 8,
                    }}
                  >
                    New Password
                  </label>
                  <input
                    type="password"
                    name="new"
                    value={passwords.new}
                    onChange={handlePasswordChange}
                    style={{
                      width: "100%",
                      height: 45,
                      background: "rgba(240, 240, 240, 0.1)",
                      border: "none",
                      borderRadius: 8,
                      padding: "0 15px",
                      color: "#f7f4f1",
                      fontSize: 16,
                    }}
                    required
                  />
                </div>

                {/* Confirm Password */}
                <div>
                  <label
                    style={{
                      display: "block",
                      color: "#f7f4f1",
                      fontFamily: "Readex Pro, sans-serif",
                      fontSize: 14,
                      marginBottom: 8,
                    }}
                  >
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    name="confirm"
                    value={passwords.confirm}
                    onChange={handlePasswordChange}
                    style={{
                      width: "100%",
                      height: 45,
                      background: "rgba(240, 240, 240, 0.1)",
                      border: "none",
                      borderRadius: 8,
                      padding: "0 15px",
                      color: "#f7f4f1",
                      fontSize: 16,
                    }}
                    required
                  />
                </div>
              </div>

              <div style={{ marginTop: 30, display: "flex", justifyContent: "flex-end" }}>
                <button
                  type="submit"
                  style={{
                    background: "linear-gradient(90deg, #300101 6%, #7b0303 50%, #960404 95%)",
                    border: "none",
                    borderRadius: 8,
                    padding: "10px 30px",
                    color: "#f7f4f1",
                    fontSize: 16,
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;