// mockBookingService.js - Use this for frontend testing before backend integration
import axios from 'axios';
import { toast } from 'react-toastify';

// Mock data
const tracks = [
  {
    id: 1,
    name: "Kool Karterz",
    description: "Our most popular track with 12 challenging turns",
    imageUrl: "/images/track1.jpg",
    pricePerSlot: 35.99,
  },
  {
    id: 2,
    name: "Kartz 4 Karterz",
    description: "Family-friendly track with smooth terrain",
    imageUrl: "/images/track2.jpg",
    pricePerSlot: 29.99,
  },
  {
    id: 3,
    name: "Karting Karterz",
    description: "Professional track with advanced features",
    imageUrl: "/images/track3.jpg", 
    pricePerSlot: 45.99,
  }
];

// Generate today and next 21 days (3 weeks)
const generateDates = () => {
  const dates = [];
  const today = new Date();
  
  for (let i = 0; i < 21; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    dates.push(date.toISOString().split('T')[0]);
  }
  
  return dates;
};

// Generate time slots for a specific date (30-minute intervals from 9 AM to 8 PM)
const generateTimeSlots = (trackId, date) => {
  const slots = [];
  const slotDate = new Date(date);
  
  // Set starting time to 9 AM
  slotDate.setHours(9, 0, 0, 0);
  
  // Create slots from 9 AM to 8 PM (last slot at 7:30 PM)
  for (let i = 0; i < 22; i++) {
    const startTime = new Date(slotDate);
    
    // Move to next 30-minute slot
    slotDate.setMinutes(slotDate.getMinutes() + 30);
    const endTime = new Date(slotDate);
    
    // Randomly mark some slots as booked (about 30%)
    const booked = Math.random() < 0.3;
    
    slots.push({
      id: trackId * 1000 + i,
      trackId: trackId,
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      booked: booked,
      price: tracks.find(t => t.id === trackId)?.pricePerSlot || 29.99
    });
  }
  
  return slots;
};

// Available dates for each track (same for all tracks in this mock)
const availableDates = generateDates();

// Mock interceptor for axios
const setupMockApi = () => {
  // Add a response interceptor
  axios.interceptors.response.use(
    response => response, // Pass successful responses through
    error => {
      // Check if this is a request we want to mock
      const { config } = error;
      if (!config || !config.url) return Promise.reject(error);
      
      const url = config.url;
      
      // Handle different API endpoints
      if (url.includes('/api/v1/tracks/')) {
        const trackId = parseInt(url.split('/').pop());
        const track = tracks.find(t => t.id === trackId);
        
        if (track) {
          console.log('[Mock API] Returning track data:', track);
          return Promise.resolve({ data: track });
        }
      }
      
      else if (url.includes('/api/v1/bookings/available-dates/')) {
        const trackId = parseInt(url.split('/').pop());
        
        console.log('[Mock API] Returning available dates for track', trackId);
        return Promise.resolve({ 
          data: { 
            dates: availableDates 
          } 
        });
      }
      
      else if (url.includes('/api/v1/bookings/available-slots/')) {
        const urlParts = url.split('/');
        const trackId = parseInt(urlParts[urlParts.length - 2]);
        const date = urlParts[urlParts.length - 1];
        
        const slots = generateTimeSlots(trackId, date);
        console.log('[Mock API] Returning time slots for track', trackId, 'on', date);
        return Promise.resolve({ 
          data: { 
            slots: slots 
          } 
        });
      }
      
      else if (url.includes('/api/v1/bookings/reserve') && config.method === 'post') {
        console.log('[Mock API] Reserving slot', config.data);
        return Promise.resolve({ 
          data: { 
            success: true,
            message: "Slot reserved successfully",
            reservationId: "res_" + Math.random().toString(36).substring(2, 10)
          } 
        });
      }
      
      // If not a mocked endpoint, pass through the error
      return Promise.reject(error);
    }
  );
  
  console.log('[Mock API] Mock booking service initialized');
};

// Set up a booking service with custom methods
export const bookingService = {
  // Initialize the mock service
  init: () => {
    setupMockApi();
    console.log('Mock Booking Service initialized');
    toast.info('Using mock booking data for testing');
  },
  
  // Get track information
  getTrack: async (trackId) => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL || ''}/api/v1/tracks/${trackId}`);
      return response.data;
    } catch (error) {
      console.error("Error fetching track:", error);
      throw error;
    }
  },
  
  // Get available dates for a track
  getAvailableDates: async (trackId) => {
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL || ''}/api/v1/bookings/available-dates/${trackId}`
      );
      return response.data.dates || [];
    } catch (error) {
      console.error("Error fetching available dates:", error);
      throw error;
    }
  },
  
  // Get available slots for a track on a specific date
  getAvailableSlots: async (trackId, date) => {
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL || ''}/api/v1/bookings/available-slots/${trackId}/${date}`
      );
      return response.data.slots || [];
    } catch (error) {
      console.error("Error fetching slots:", error);
      throw error;
    }
  },
  
  // Reserve a slot
  reserveSlot: async (trackId, slotId, date) => {
    try {
      const response = await axios.post(
        `${import.meta.env.VITE_API_BASE_URL || ''}/api/v1/bookings/reserve`,
        { trackId, slotId, date }
      );
      return response.data;
    } catch (error) {
      console.error("Error reserving slot:", error);
      throw error;
    }
  }
};

export default bookingService;