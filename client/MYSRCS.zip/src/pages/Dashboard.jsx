// Dashboard.jsx
import { useState, useEffect } from "react";
import { toast } from 'react-toastify';
import axios from 'axios';
import { UserProfile, SideNavBar } from "../components";
import { WelcomeCard, JourneyCard, LeaderboardSection } from "../components/dashboard";
import { useUser } from "../context/UserContext";
import "../styles/common-components.css";

const Dashboard = () => {
  const { userData, userStats, isLoading } = useUser();
  const [leaderboardData, setLeaderboardData] = useState([]);

  const fetchLeaderboard = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/v1/dashboard/leaderboard`);
      setLeaderboardData(response.data.users || []);
    } catch (error) {
      toast.error("Failed to fetch leaderboard");
      console.error(error);
    }
  };

  useEffect(() => {
    fetchLeaderboard();
  }, []); // run only once

  // Show loading indicator while user data is being fetched
  if (isLoading) {
    return (
      <div
        style={{
          width: "100%",
          height: 982,
          position: "relative",
          background: "linear-gradient(90deg, black 26%, #1B1B1B 53%, #1F1F1F 74%, #242424 83%, #272727 93%)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          color: "white",
          fontSize: "18px",
          fontFamily: "Readex Pro",
        }}
      >
        Loading dashboard...
      </div>
    );
  }

  return (
    <div
      style={{
        width: "100%",
        height: 982,
        position: "relative",
        background: "linear-gradient(90deg, black 26%, #1B1B1B 53%, #1F1F1F 74%, #242424 83%, #272727 93%)",
        overflow: "hidden",
      }}
    >
      {/* Left Sidebar - now accesses user data from context */}
      <SideNavBar />
      
      {/* User Profile - now accesses user data from context */}
      <UserProfile style={{ position: "absolute", top: 30, right: 40 }} />

      {/* Welcome Card - now accesses user data from context */}
      <WelcomeCard 
        style={{
          position: "absolute",
          left: 363,
          top: 30,
          width: 581,
          height: 179.94,
        }}
      />

      {/* Journey Card - now accesses user data from context */}
      <JourneyCard 
        style={{
          position: "absolute",
          left: 363,
          top: 268,
          width: 581,
          height: 700,
        }}
      />

      {/* Divider Line - before Community Leaderboard */}
      <div style={{
        position: "absolute",
        top: "0px",
        left: "1015px",
        height: "982px",
        width: "1px",
        backgroundColor: "#F7F4F1",
        opacity: 0.3
      }} />

      {/* Community Statistics */}
      <div
        style={{
          position: "absolute",
          left: 1057,
          top: 133,
          color: "#C9C0C0",
          fontSize: 23,
          fontFamily: "Readex Pro",
          fontWeight: "550",
        }}
      >
        Community Leaderboard
      </div>
   
      {/* Leaderboard - now accesses user data from context when needed */}
      <LeaderboardSection 
        leaderboardData={leaderboardData}
        style={{
          position: "absolute",
          left: 1057,
          top: 200,
          width: 343,
        }}
      />
    </div>
  );
};

export default Dashboard;