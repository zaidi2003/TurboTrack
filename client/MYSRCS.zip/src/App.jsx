import { RouterProvider, createBrowserRouter } from "react-router-dom";
import {
  Dashboard,
  HomeLayout,
  Landing,
  Login,
  Logout,
  Register,
  BecomeAPartner,
  Test,
  NotFound,
  ChangePassword,
  Account,
  Booking,
  SheetBooking,
  PaymentPage, 
} from "./pages";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import DashboardRoutes from "./routes/dashboardRoutes";
import { UserProvider } from "./context/UserContext";

const router = createBrowserRouter([
  {
    path: "/",
    element: <HomeLayout />,
    children: [
      {
        index: true,
        element: <Landing />,
      },
      {
        path: "change-password",
        element: <ChangePassword />,
      },
      {
        path: "account",
        element: <Account />,
      },
      {
        path: "login",
        element: <Login />,
      },
      {
        path: "register",
        element: <Register />,
      },
      {
        path: "logout",
        element: <Logout />,
      },
      {
        path: "become-a-partner",
        element: <BecomeAPartner />,
      },
      {
        path: "dashboard/*",
        element: <DashboardRoutes />,
      },
      {
        path: "test",
        element: <Test />,
      },
      {
        path: "bookings", 
        element: <Booking />,
      },
      {
        path: "bookings/sheet/:trackName",
        element: <SheetBooking />,
      },
      {
        path: "bookings/sheet/:trackName/checkout", 
        element: <PaymentPage />,
      },
      {
        path: "*",
        element: <NotFound />,
      },
    ],
  },
]);

function App() {
  return (
    <UserProvider>
      <RouterProvider router={router} />
      <ToastContainer position="top-center" />
    </UserProvider>
  );
}

export default App;