// src/context/index.js
export { UserProvider, useUser, default as UserContext } from './UserContext';